import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { from } from 'rxjs';

const routes: Routes = [


  {
    path:'',loadChildren:"./login/login.module#LoginModule"
  },
  {
    path:'dashboard',loadChildren:'./dashboard/dashboard.module#DashboardModule'
    // loadChildren:()=>dashboardModule\
  },
  {
    path:'profile',loadChildren:'./profile/profile.module#ProfileModule'
    // loadChildren:()=>ProfileModule\
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
