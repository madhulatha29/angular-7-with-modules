import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { ProfilepageComponent } from './profilepage/profilepage.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'; 
@NgModule({
  declarations: [ProfilepageComponent],
  imports: [
    CommonModule,
    ProfileRoutingModule,FormsModule,HttpClientModule
  ]
  
})
export class ProfileModule { }
