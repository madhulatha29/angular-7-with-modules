import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BlankpageComponent } from './blankpage/blankpage.component';
import { AuthGuard } from '../gaurds/auth.guard';
const routes: Routes = [
 { path:'',component:BlankpageComponent,canActivate:[AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
