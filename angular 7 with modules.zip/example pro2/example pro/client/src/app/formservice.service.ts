import { Injectable } from '@angular/core';
import{Observable} from 'rxjs'
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FormserviceService {

  constructor(private http:HttpClient) { }
  
  login(model):Observable<any>{
debugger
return this.http.post('http://localhost:4400' +'/post',{fn:model.firstname,ln:model.lastname})
  }

  proifle(model):Observable<any>{
    debugger
    return this.http.post('http://localhost:4400' +'/prof',{name:model.name,email:model.email,mobile:model.mobile,file:model.image}) 
  }
  
  get1():Observable<any>{
    debugger
    return this.http.get('http://localhost:4400'+'/get')
  }
}
